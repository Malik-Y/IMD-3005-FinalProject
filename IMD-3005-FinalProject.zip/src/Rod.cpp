#include "Rod.h"

Rod::Rod(float x, float y, float maxLen) {
    tip.set(x, y);
    hook = tip;
    lineLength = 0;
    maxLineLength = maxLen;
    tension = 0.0f;
    maxTension = 5.0f;
    hookImg.load("hook.png");
    rodCastingImg.load("rod.png");
    rodReelingImg.load("rod2.png");
    

}

void Rod::update(bool isCasting, bool isReeling, int m_flex_val) {
    if (isCasting) {
        if (m_flex_val != 7)
        {
            lineLength = ofClamp(lineLength + 4, 0, maxLineLength);
        }

    
         

    }
    else if (isReeling) {


        if (m_flex_val != 7)
        {
            lineLength = ofClamp(lineLength - 4, 0, maxLineLength);
        }
    
    }
    hook.y = tip.y + lineLength;



    
}

void Rod::draw(bool isCasting) {
    if (isCasting)
    {

       ofImage& rodImage = rodReelingImg;
       rodImage.draw(tip.x - 350, tip.y - 200, 400, 400); 
    }
    else
    {
       ofImage& rodImage = rodCastingImg;
       rodImage.draw(tip.x - 350, tip.y - 100, 400, 400); 
    }
     
    

    ofSetColor(0, 0, 0);
    ofDrawLine(tip.x, tip.y, hook.x, hook.y);
    ofPushMatrix();
    hookImg.resize(100, 100);
    ofTranslate(-40, -10);
    hookImg.draw(hook.x, hook.y); 
    ofPopMatrix();

}
