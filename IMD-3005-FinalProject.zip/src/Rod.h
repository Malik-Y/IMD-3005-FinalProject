#pragma once
#include "ofMain.h"

class Rod {
public:
    float tension;    
    float maxTension;
    ofPoint tip;
    ofPoint hook;
    ofImage hookImg;
    float lineLength;
    float maxLineLength;
    ofImage rodCastingImg; 
    ofImage rodReelingImg;
    

    Rod(float x, float y, float maxLen);

    void update(bool isCasting, bool isReeling);
    void draw(bool isCasting);
};
