#include "Fish.h"

Fish::Fish(float x, float y, float spd, ofImage& image) {
    position.set(x, y);
    speed = spd;
    fishImage = image;  
    caught = false;
}

void Fish::update() {

    if (!caught) {
        position.x += speed;
    }
    if (position.x > ofGetWindowWidth() || position.x < 500) {
        speed = -speed; 
        
    }
   
}

void Fish::draw() {
    ofPushMatrix();
    
    if (speed > 0) {
       
        ofTranslate(position.x + fishImage.getWidth(), position.y); 
        ofScale(-1, 1); 
    }
    else {
       
        ofTranslate(position.x, position.y);
    }

    fishImage.draw(0, 0); 

    ofPopMatrix(); 
}


void Fish::reelIn(ofPoint rodHook) {
    if (caught) {
       
        if (position.y > rodHook.y) {
            position.y -= 5;  
        }
        
    }
}