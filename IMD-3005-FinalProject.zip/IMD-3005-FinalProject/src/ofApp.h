#pragma once
#include "ofMain.h"
#include "Fish.h"
#include "Rod.h"
#include "TensionMeter.h"
#include "ofxImGui.h"

namespace config {
    static const std::string ARDUINO_DEVICE_NAME = "COM3";		//WIN
    //static const std::string ARDUINO_DEVICE_NAME = "/dev/cu.usbmodem144101";	//MAC
};

enum GameState {
    START,
    RUNNING,
    PAUSED
};

class ofApp : public ofBaseApp {
public:
    static const int PIN_PMETER_INPUT = 1;
    static const int PIN_FLEX_INPUT = 0;
    ofArduino m_arduino;
    ofTrueTypeFont          m_font;
    int    m_flex_val;//sensor value
    int    m_pMeter_val;
    float lineLength;
    int m_rotations;

    bool m_bSetup;       //is Arduinio initialized yet
    void setupArduino(const int& _version);
    void updateArduino();
    //void digitalPinChanged(const int& pinNum);
    void analogPinChanged(const int& pinNum);
    

    void setup();
    void update();
    void draw();

    void setupFish();
    void updateFish();
    void checkCatch();
    void drawGame();
    void drawStartScreen();
    void drawPauseScreen();
    void resetGame();
    void keyPressed(int key);
    void calibratePotentiometer(float p_val, float lineLength);
    

    GameState currentState;
    ofApp();
    ofxImGui::Gui gui;
    Rod rod;
    TensionMeter tensionMeter;
    vector<Fish> fishList;
    int score;
    string lastCaughtFish;
    bool isFishCaught = false;
    bool isCasting;
    bool isReeling;

    ofTrueTypeFont font;
    ofImage background;
    ofImage land;
    vector<ofImage> fishImages;
    vector<string> fishNames;
};