#include "ofApp.h"


ofApp::ofApp()
    : rod(800, 250, 600),      
    tensionMeter(&rod)         
{
    score = 0;
}

void ofApp::setup() {
    ofToggleFullscreen();
    //Arduino
    m_arduino.connect(config::ARDUINO_DEVICE_NAME, 57600);
    ofAddListener(m_arduino.EInitialized, this, &ofApp::setupArduino);
    m_bSetup = false;
    m_pMeter_val = 0.0f;
    m_flex_val = 0.0f;
    lineLength = 0.0f;

    

    currentState = START;

    isFishCaught = false;

    background.load("background.png");
    background.resize(500, 500);
 
    lastCaughtFish = "";

    m_rotations = 0;

    fishNames.push_back("salmon");
    fishNames.push_back("koi");
    fishNames.push_back("peacock shrimp");
    fishNames.push_back("Brandon");
    fishNames.push_back("dorade");
    fishNames.push_back("ghost shark");
    fishNames.push_back("fish curry");
    

    fishImages.push_back(ofImage("fish-salmon.png"));
    fishImages.push_back(ofImage("fish-koi.png"));
    fishImages.push_back(ofImage("fish-peacock-shrimp.png"));
    fishImages.push_back(ofImage("fish-brandon.png"));
    fishImages.push_back(ofImage("fish-dorade.png"));
    fishImages.push_back(ofImage("fish-ghost-shark.png"));
    fishImages.push_back(ofImage("fish-curry.png"));

    // Resize fish
    for (auto& fishImages : fishImages) {
        fishImages.resize(100, 100);
    }

    // Setup fish
    setupFish();
    gui.setup();

    font.loadFont("bubble.ttf",50);
    isReeling = true;
}

void ofApp::update() {
    
    updateArduino();
    

    // Update rod mechanics
    rod.update(isCasting, isReeling, m_pMeter_val, m_flex_val);

    updateFish();
    checkCatch();
   
    

   
}

void ofApp::draw() {
    
    switch (currentState) {
    case START:
        drawStartScreen();
        break;
    case RUNNING:
        drawGame();
        break;
    case PAUSED:
        drawPauseScreen();
        break;
    }
    if (m_bSetup)
    {
        ofDrawBitmapString("Flex Val is:" + ofToString(m_flex_val), 10, 30);
       
    }
}

void ofApp::setupFish() {
    // Create fish with random positions and speeds
    for (int i = 0; i < 12; i++) {
        int randomFish = ofRandom(0, fishImages.size());
        fishList.push_back(Fish(ofRandom(500, ofGetWidth()), ofRandom(760, 900), ofRandom(1, 3), fishImages[randomFish], fishNames[randomFish]));
    }
}

void ofApp::updateFish() {
    for (auto it = fishList.begin(); it != fishList.end(); ) {
        if (it->caught) {
            // Reel in the fish by a fixed step, move towards the hook
            it->reelIn(rod.hook);  // 5.0 is the speed for reeling in

       // else (if )

            // If the fish has reached the hook, it is reeled in and should be removed from the list
            if (it->caught && it->position.y<=250) {  // The fish has been reeled in and is no longer caught
                lastCaughtFish = it->name;
                it = fishList.erase(it); // Remove the fish from the list
                score += 10; // Increase the score
                
                
                isFishCaught = false;
            }
            else {
                ++it; // Keep it in the list if it's still being reeled in
            }
        }
        else {
            it->update(); 
            ++it;
        }
    }
}
void ofApp::checkCatch() {
   
    if (!isFishCaught) {
        isCasting = true;
        for (auto& fish : fishList) {
            if (!fish.caught && ofDist(rod.hook.x, rod.hook.y, fish.position.x, fish.position.y) <= 30) {
                fish.caught = true;
                isFishCaught = true;
                isReeling = true;
               // isCasting = false;
            }

        }
    }

}

void ofApp::drawGame() {

    background.draw(0, 0, ofGetWidth(), ofGetHeight());
    ofSetColor(0);
    ofDrawBitmapString("Score: " + ofToString(score), 10, 20);
    if (lastCaughtFish != "") {
        ofDrawBitmapString("You caught a " + lastCaughtFish + "!", 1300, 200);
    }
    ofDrawBitmapString("Fishy Fish Fishing", 900, 20);
    ofDrawBitmapString("Tab to pause", ofGetWindowWidth()-100, 20);

    ofSetColor(255, 255, 255, 255);
    rod.draw(isFishCaught);
    for (auto& fish : fishList) {
        ofPushMatrix();
        ofSetColor(200, 200, 200, 255);
        fish.draw();
        ofPopMatrix();
    }

    //tensionMeter.draw();

    
}

void ofApp::drawStartScreen() { 
    ofSetColor(255,0,0);
    font.drawString("Fishy Fish Fishing", ofGetWindowWidth()/3 ,ofGetWindowHeight()/4);
    ofSetColor(255, 255, 255, 30);
    background.draw(0, 0, ofGetWidth(), ofGetHeight());
    gui.begin();

   
   
    ImGui::SetNextWindowPos(ImVec2(ofGetWindowWidth()/ 2, ofGetWindowHeight()/ 2));

    ImGui::Begin("Start Screen");
    ImGui::Text("Welcome to Fishy Fish Fishing!");
    if (ImGui::Button("Start Game")) {
        
        currentState = RUNNING;
        
        
    }
    ImGui::End();
    gui.end();
}

void ofApp::drawPauseScreen() {
    gui.begin();

   
    ImGui::SetNextWindowPos(ImVec2(ofGetWindowWidth() / 2, ofGetWindowHeight() / 2));

    ImGui::Begin("Pause Menu");
    ImGui::Text("Game Paused");
    if (ImGui::Button("Resume")) {
        currentState = RUNNING;
    }
    if (ImGui::Button("Quit to Start")) {
        currentState = START;
        resetGame();
    }
    ImGui::End();
    gui.end();
}


void ofApp::resetGame() {
    fishList.clear();
    setupFish();
    score = 0;
    isFishCaught = false;
}

void ofApp::keyPressed(int key) {
    if (key == OF_KEY_TAB && currentState == RUNNING) {
        currentState = PAUSED; 
    }
    else if (key == OF_KEY_TAB && currentState == PAUSED) {
        currentState = RUNNING;
    }
}

void ofApp::setupArduino(const int& _version)
{
    /**
     Look under examples/communication/firmata for more examples ..
     **/

    m_bSetup = true;

    // remove listener because we don't need it anymore
    ofRemoveListener(m_arduino.EInitialized, this, &ofApp::setupArduino);

    // print firmware name and version to the console
    ofLogNotice() << m_arduino.getFirmwareName();
    ofLogNotice() << "firmata v" << m_arduino.getMajorFirmwareVersion() << "." << m_arduino.getMinorFirmwareVersion();

    //analog input
    m_arduino.sendAnalogPinReporting(PIN_PMETER_INPUT, ARD_ANALOG);

    //PMW/digital output
    m_arduino.sendAnalogPinReporting(PIN_FLEX_INPUT, ARD_ANALOG);

    //ofAddListener(m_arduino.EDigitalPinChanged, this, &ofApp::digitalPinChanged);
    ofAddListener(m_arduino.EAnalogPinChanged, this, &ofApp::analogPinChanged);
}

void ofApp::updateArduino() {

    // update the arduino, get any data or messages.
    // the call to m_arduino.update() is required
    m_arduino.update();
}

void ofApp::analogPinChanged(const int& pinNum) {
    //std::cout  << "analog pin: " + ofToString(pinNum) + " : " + ofToString(m_arduino.getAnalog(pinNum)) << std::endl;
    if (pinNum == PIN_FLEX_INPUT) {

        //get analog value
        m_flex_val = m_arduino.getAnalog(pinNum);
        m_flex_val = (int)ofMap(m_flex_val, 0, 1023, 0, 255);

        //send out pmw value
        //m_arduino.sendPwm(PIN_FLEX_OUTPUT, (int)m_input_val);
    }
    if (pinNum == PIN_PMETER_INPUT) {

        //get analog value
        m_pMeter_val = m_arduino.getAnalog(pinNum);
        m_pMeter_val = (int)ofMap(m_pMeter_val, 0, 1023, 0, 600);


        //send out pmw value
        //m_arduino.sendPwm(PIN_FLEX_OUTPUT, (int)m_input_val);
    }

}











