#pragma once
#include "ofMain.h"


class Fish {
public:
    ofPoint position;
    float speed;
    ofImage fishImage;  
    string name;
    Fish(float x, float y, float spd, ofImage& image, string fishName);
    bool caught;
    void reelIn(ofPoint hook);
    void update();
    void draw();

};

