#pragma once
#include "ofMain.h"


class Rod {
public:
    float tension;    
    float maxTension;
    ofPoint tip;
    ofPoint hook;
    ofImage hookImg;
    float lineLength;
    float maxLineLength;
    ofImage rodCastingImg; 
    ofImage rodReelingImg;
    int m_rotations;
    

    Rod(float x, float y, float maxLen);

    void update(bool isCasting, bool isReeling, float m_pMeter_val, int m_flex_val);
    void draw(bool isCasting);
};
