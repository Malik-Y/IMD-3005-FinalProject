#include "Rod.h"

Rod::Rod(float x, float y, float maxLen) {
    tip.set(x, y);
    hook = tip;
    lineLength = 0;
    maxLineLength = maxLen;
    tension = 0.0f;
    maxTension = 5.0f;
    hookImg.load("hook.png");
    rodCastingImg.load("rod.png");
    rodReelingImg.load("rod2.png");
    

}

void Rod::update(bool isCasting, bool isReeling, float m_pMeter_val, int m_flex_val) {
    if (isCasting) {
        lineLength = m_pMeter_val;
    }
    else if (isReeling) {
       
        static const int initFlexVal = m_flex_val;
        ofLog() << initFlexVal;
        if (m_flex_val < initFlexVal && m_flex_val >= 6)
        {
            lineLength = ofClamp(lineLength - 6, 0, maxLineLength);
        }
        else if (m_flex_val > initFlexVal && m_flex_val <= 8)
        {
            lineLength = ofClamp(lineLength + 6, 0, maxLineLength);
        }
          
        //tension += 0.1;
        /*if (ofGetKeyPressed(OF_KEY_SHIFT))
        {
            lineLength = ofClamp(lineLength - 2, 0, maxLineLength);
            tension += 0.1f;
        }*/
    }
    hook.y = tip.y + lineLength;


    if (tension > maxTension) {
        tension = 0;
        lineLength = 0;

    }
    else if (tension < maxTension && tension >= 0) {
        tension -= 0.1f; 
    }
}

void Rod::draw(bool isCasting) {
    if (isCasting)
    {

       ofImage& rodImage = rodReelingImg;
       rodImage.draw(tip.x - 350, tip.y - 200, 400, 400); 
    }
    else
    {
       ofImage& rodImage = rodCastingImg;
       rodImage.draw(tip.x - 350, tip.y - 100, 400, 400); 
    }
     
    

    ofSetColor(0, 0, 0);
    ofDrawLine(tip.x, tip.y, hook.x, hook.y);
    ofPushMatrix();
    hookImg.resize(100, 100);
    ofTranslate(-40, -10);
    hookImg.draw(hook.x, hook.y); 
    ofPopMatrix();

}
/*void Rod::calibratePotentiometer(float p_val, float lineLength)
{

    lineLength = (int)ofMap(p_val, 0, 1024, 0, 600);
}*/