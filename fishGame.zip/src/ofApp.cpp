#include "ofApp.h"

//--------------------------------------------------------------
void ofApp::setup(){
	ofSetWindowTitle("Fish Game");

	arduino.listDevices();
	vector <ofSerialDeviceInfo> deviceList = arduino.getDeviceList();

	arduino.setup("COM3", 9600);
}

//--------------------------------------------------------------
void ofApp::update(){
	int myByte = 0;
	myByte = arduino.readByte();
	if (myByte == OF_SERIAL_NO_DATA)
		printf("\nno data was read");
	else if (myByte == OF_SERIAL_ERROR)
		printf("\nan error occurred");
	else
		printf("\nmyByte is %d ", myByte);
}

//--------------------------------------------------------------
void ofApp::draw(){

}

void ofApp::castFishingRod(){
	//map flex sensor to strength val
	/*flexSensorStrength = ofMap(flexSensorStrength, minInput, maxInput, minOutput, maxOutput);*/
	strength = flexSensorStrength;

	distanceX = strength;
}
