#pragma once

#include "ofMain.h"
#include "ofArduino.h"

class ofApp : public ofBaseApp{

	public:
		void setup();
		void update();
		void draw();
		
		
		ofSerial arduino;
		int score;
		float distanceX;
		float strength;
		float flexSensorStrength;
		int tension;

		ofImage pond;

		void castFishingRod();

		
};
