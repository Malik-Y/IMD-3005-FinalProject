#pragma once
#include "ofMain.h"
#include "Fish.h"
#include "Rod.h"
#include "TensionMeter.h"
#include "ofxImGui.h"

enum GameState {
    START,
    RUNNING,
    PAUSED
};

class ofApp : public ofBaseApp {
public:

    void setup();
    void update();
    void draw();

    void setupFish();
    void updateFish();
    void checkCatch();
    void drawGame();
    void drawStartScreen();
    void drawPauseScreen();
    void resetGame();
    void keyPressed(int key);

    GameState currentState;
    ofApp();
    ofxImGui::Gui gui;
    Rod rod;
    TensionMeter tensionMeter;
    vector<Fish> fishList;
    int score;
    bool isFishCaught = false;
    bool isCasting;
    bool isReeling;

    ofTrueTypeFont font;
    ofImage background;
    ofImage land;
    vector<ofImage> fishes;
};