#include "Rod.h"

Rod::Rod(float x, float y, float maxLen) {
    tip.set(x, y);
    hook = tip;
    lineLength = 0;
    maxLineLength = maxLen;
    tension = 0.0f;
    maxTension = 5.0f;
    hookImg.load("hook.png");
    rodCastingImg.load("rod.png");
    rodReelingImg.load("rod2.png");
}

void Rod::update(bool isCasting, bool isReeling) {
    if (isCasting) {
            lineLength = ofClamp(lineLength + 2, 0, maxLineLength);
    }
    else if (isReeling) {
            lineLength = ofClamp(lineLength - 2, 0, maxLineLength);
            tension += 0.5;
    }
    hook.y = tip.y + lineLength;
    

    /*if (tension > maxTension) {
        ofLog() << "Line snapped!";
        tension = 0; 
       
    }
    else {
        tension -= 0.1; 
    }*/
}

void Rod::draw(bool isCasting) {
    if (isCasting)
    {
       ofImage& rodImage = rodReelingImg;
       rodImage.draw(tip.x - 350, tip.y - 200, 400, 400); 
    }
    else
    {
       ofImage& rodImage = rodCastingImg;
       rodImage.draw(tip.x - 350, tip.y - 100, 400, 400); 
    }
     
    

    ofSetColor(0, 0, 0);
    ofDrawLine(tip.x, tip.y, hook.x, hook.y);
    ofPushMatrix();
    hookImg.resize(100, 100);
    ofTranslate(-40, -10);
    hookImg.draw(hook.x, hook.y); 
    ofPopMatrix();

}
